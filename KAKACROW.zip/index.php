<?php
header('Location:home/');
?>